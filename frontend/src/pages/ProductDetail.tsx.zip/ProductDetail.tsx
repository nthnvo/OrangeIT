import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useCart } from "./CartContext";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { Shield, ChevronLeft, ChevronRight, Share2, Heart, BarChart2 } from "lucide-react";

const mockProducts: Record<string, any> = {
  "1": {
    id: 1, brand: "APPLE", sku: "195951030982",
    title: "Apple iPhone 17e 256GB Soft Pink", price: 22900,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: true,
    images: ["/img/iPhone 17e.jpg", "/img/iPhone 17e1.jpg", "/img/iPhone 17e2.jpg"],
    capacities: ["256GB"],
    colors: [{ name: "Soft Pink", hex: "#1a1a1a" }],
    defaultColor: "Soft Pink",
    applecare: { name: "AppleCare+ for iPhone 17e (แผน 2 ปี)", price: 4190, image: "/img/applecare.jpg" },
    bundle: { label: "iPhone 17e + Accessories", bundlePrice: 25010, image: "/img/bundle.jpg" },
    description: "iPhone 17e จาก Apple สมาร์ทโฟนดีไซน์คุ้มค่า มาพร้อมจอ Super Retina XDR 6.1 นิ้ว ชิป A19 กล้อง Fusion 48MP รองรับ USB-C และ MagSafe",
    specs: ["จอ Super Retina XDR 6.1 นิ้ว", "ชิป A19", "กล้อง Fusion 48MP", "แบต 26 ชั่วโมง", "รองรับ USB-C และ MagSafe"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },
  "2": {
    id: 2, brand: "XIAOMI", sku: "6932554483944",
    title: "สมาร์ทโฟน Xiaomi 17 Ultra (16+512GB) Starlit Green (5G)", price: 44990,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: [],
    colors: [{ name: "Starlit Green" }],
    defaultColor: "Starlit Green",
    description: "Xiaomi 17 Ultra สมาร์ทโฟนเรือธงสำหรับสายถ่ายภาพ ด้วยพลังของ Essential Leica Imagery มิติภาพระดับพรีเมียมในแบบฉบับ Leica ขับเคลื่อนด้วยขุมพลัง Snapdragon 8 Elite Gen 5 เร็วแรง ลื่นไหล รองรับการประมวลผลภาพขั้นสูง สั้งซื้อได้แล้ววันนี้ที่ BaNANA",
    specs: ["Bluetooth จอ 6.85 inch รีเฟรชเรท 120Hz.3", "กล้องหน้า 50MP + กล้องหลัง 50MP", "แบตเตอรี่ 6,000 mAh ชาร์จไว 90W ชาร์จไร้สาย 50W"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },
  "3": {
    id: 3, brand: "SONY", sku: "4948872964159",
    title: "จอยคอนโทรลเลอร์ Sony DualSense Midnight Black + USB Cable for PC", price: 2590,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: [],
    colors: [],
    description: "จอยคอนโทรลเลอร์ DualSense จาก BaNANA นิยามใหม่ของการดื่มด่ำในเกม PC ปลดปล่อยพลังแห่งการควบคุมที่ละเอียดอ่อนและสมจริง ไม่ว่าจะเป็นแรงต้านของอาวุธหรือสภาพแวดล้อมในเกมระดับ AAA ก็ถ่ายทอดออกมาได้อย่างยอดเยี่ยม ที่สุดของไอเทมที่จะเปลี่ยนคอมพิวเตอร์ของคุณให้กลายเป็นสนามรบสุดมัน",
    specs: ["รองรับ PS5, PC, macOS, Android, iOS", "ไมโครโฟนและช่องเสียบหูในตัว", "สัมผัสการจับที่กระชับมือ"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },
  "4": {
    id: 4, brand: "XIAOMI", sku: "6932554472870",
    title: "แท็บเล็ต Xiaomi Pad 8 Wi-Fi (8+256GB) Gray", price: 15990,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: ["8+256GB"],
    colors: [{ name: "Gray", hex: "#808080" }],
    defaultColor: "Gray",
    description: "Xiaomi Pad 8 Wi-Fi  สัมผัสประสบการณ์ใหม่ของแท็บเล็ตระดับไฮเอนด์ Xiaomi Pad 8 ที่รวมความแรงของชิปเซ็ตรุ่นล่าสุด เข้ากับหน้าจอความละเอียดสูงระดับ 3.2K ให้คุณใช้งานได้เต็มประสิทธิภาพไม่ว่าจะทำงานระดับมืออาชีพ หรือรับชมความบันเทิงสุดล้ำ ซื้อสินค้าแล้วได้ที่ BaNANA",
    specs: ["ชิป Snapdragon 8s Gen 4", "ขนาดหน้าจอใหญ่ 11.2  นิ้ว", "แบตเตอรี่ 9,200 mAh  ใช้งานได้อย่างยาวนาน"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },
  "5": {
    id: 5, brand: "VIVO", sku: "6932204518934",
    title: "สมาร์ทโฟน vivo V70 (12+512GB) Alpine Gray (5G)", price: 20999,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: ["12+512GB"],
    colors: [{ name: "Alpine Gray" }],
    defaultColor: "Alpine Gray",
    description: "vivo V70 สมาร์ทโฟนดีไซน์พรีเมียม พร้อมกล้อง AI คมชัดระดับโปร หน้าจอความละเอียดสูงลื่นไหลเต็มตา แบตอึดใช้งานยาวนาน และประสิทธิภาพแรงตอบโจทย์ทุกไลฟ์สไตล์ ทั้งถ่ายภาพ เล่นโซเชียล ทำงาน และความบันเทิงครบจบในเครื่องเดียว สวยระดับลูกรักพระเจ้า พร้อมของแถมมากมายที่ BaNANA 📱✨",
    specs: ["จอ Amoled 6.59 นิ้ว รีเฟรชเรท 120Hz", "กล้องหลัก 50MP กล้องหน้า 50MP", "แบต 6,500 mAh ชาร์จเร็ว 90W"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },
  "6": {
    id: 6, brand: "SONY", sku: "4548736171831",
    title: "หูฟังไร้สาย Sony WF-1000XM6 Silver", price: 11990,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: [],
    colors: [{ name: "Silver" }],
    defaultColor: "Silver",
    description: "Sony WF-1000XM6 หูฟังไร้สาย True Wireless รุ่นเรือธง พร้อมเทคโนโลยีตัดเสียงรบกวนล้ำสมัย มอบการตัดเสียงรบกวนขั้นสุดยอด คุณภาพเสียงที่คมชัด และความสบายตลอดวัน ออกแบบมาสำหรับผู้ที่คาดหวังความเป็นเลิศในทุกช่วงเวลา สั่งซื้อได้แล้ววันนี้ที่ BaNANA",
    specs: ["ระบบตัดเสียงรบกวนที่ดีที่สุด พร้อมคุณภาพเสียงระดับพรีเมียม", "สวมใส่สบาย กระชับ และแนบสนิทกับหู", "Bluetooth 5.3 คุณภาพการโทรที่คมชัดยิ่งขึ้น"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },
  "7": {
    id: 7, brand: "HARMAN KARDON", sku: "1200130028298",
    title: "ลำโพงบลูทูธ Harman Kardon SoundSticks 5 White", price: 14900,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: [],
    colors: [{ name: "White" }],
    defaultColor: "White",
    description: "Harman Kardon SoundSticks 5 ลำโพงดีไซน์โดมใสระดับตำนาน มาพร้อมระบบเสียง 2.1 แชนแนลที่ทรงพลัง เบสลึกสะใจ และแสง Ambient Light ที่เคลื่อนไหวตามจังหวะเพลง พร้อมยกระดับความบันเทิงในบ้านให้เป็นโรงหนังส่วนตัวได้ง่ายๆ ด้วยการเชื่อมต่อ HDMI ARC เพียงเส้นเดียว ซื้อสินค้าแล้วได้ที่ BaNANA",
    specs: ["ดีไซน์ไอคอนิกและแสงไฟสุดล้ำ", "ระบบเสียง 2.1 ทรงพลัง 190W", "เชื่อมต่อทีวีง่ายด้วย HDMI ARC"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },
  "8": {
    id: 8, brand: "SONY", sku: "4548736175259",
    title: "หูฟังครอบหู Sony WH-1000XM6 Sand Pink", price: 11990,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: [],
    colors: [{ name: "Sand Pink" }],
    defaultColor: "Sand Pink",
    description: "Sony  WH-1000XM6 สัมผัสประสบการณ์ หูฟังครอบหู เสียงระดับพรีเมียม ระบบตัดเสียงรบกวนแบบ Adaptive Noise Cancelling อัจฉริยะ เสียงคุณภาพสูง  ใช้งานได้นานต่อเนื่อง  เหมาะสำหรับทุกไลฟ์สไตล์การฟังเพลงหรือประชุมออนไลน์ เป็นเจ้าของได้แล้วที่ BaNANA",
    specs: ["รองรับ Bluetooth 5.3", "ดีไซน์พับเก็บสะดวก", " พร้อมไมโครโฟนในตัว"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },
  "9": {
    id: 9, brand: "VIVO", sku: "6932204518651",
    title: "สมาร์ทโฟน vivo V70 (12+256GB) Authentic Black (5G)", price: 18499,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: ["12+256GB"],
    colors: [{ name: "Authentic Black" }],
    defaultColor: "Authentic Black",
    description: "vivo V70 สมาร์ทโฟนดีไซน์พรีเมียม พร้อมกล้อง AI คมชัดระดับโปร หน้าจอความละเอียดสูงลื่นไหลเต็มตา แบตอึดใช้งานยาวนาน และประสิทธิภาพแรงตอบโจทย์ทุกไลฟ์สไตล์ ทั้งถ่ายภาพ เล่นโซเชียล ทำงาน และความบันเทิงครบจบในเครื่องเดียว สวยระดับลูกรักพระเจ้า พร้อมของแถมมากมายที่ BaNANA 📱✨",
    specs: ["จอ Amoled 6.59 นิ้ว รีเฟรชเรท 120Hz", "กล้องหลัก 50MP กล้องหน้า 50MP", "แบต 6,500 mAh ชาร์จเร็ว 90W"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },
  "10": {
    id: 10, brand: "SONY", sku: "4548736171787",
    title: "หูฟังไร้สาย Sony WF-1000XM6 Black", price: 11990,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: [],
    colors: [{ name: "Black" }],
    defaultColor: "Black",
    description: "WF1000XM6 หูฟังไร้สาย True Wireless รุ่นเรือธง พร้อมเทคโนโลยีตัดเสียงรบกวนล้ำสมัย มอบการตัดเสียงรบกวนขั้นสุดยอด คุณภาพเสียงที่คมชัด และความสบายตลอดวัน ออกแบบมาสำหรับผู้ที่คาดหวังความเป็นเลิศในทุกช่วงเวลา สั่งซื้อได้แล้ววันนี้ที่ BaNANA",
    specs: ["ระบบตัดเสียงรบกวนที่ดีที่สุด พร้อมคุณภาพเสียงระดับพรีเมียม", "สวมใส่สบาย กระชับ และแนบสนิทกับหู", "Bluetooth 5.3 คุณภาพการโทรที่คมชัดยิ่งขึ้น"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },

  "11": {
    id: 11, brand: "EPSON", sku: "V11HB72352",
    title: "โปรเจคเตอร์ Epson EF-61G Ice Green", price: 20790,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: [],
    colors: [{ name: "Ice Green" }],
    defaultColor: "Ice Green",
    description: "Epson Lifestudio Pop EF-61G Ice Green โปรเจคเตอร์พกพา Full HD ดีไซน์พรีเมียม สีพาสเทลสุดมินิมอล เปลี่ยนทุกมุมบ้านให้เป็นโฮมเธียเตอร์ได้ง่าย ๆ 🎬✨ เหมาะสำหรับคนที่อยากได้โปรเจคเตอร์พกพา ภาพสวย เสียงดี ใช้งานง่าย ดีไซน์แต่งบ้านได้แบบลงตัว 💚🛒 ช้อปเลย! ที่ BaNANA",
    specs: ["Full HD คมชัดสูงสุด 150 นิ้ว ภาพใหญ่สะใจ ดูหนังเต็มอารมณ์📺", "ความสว่าง 700 ลูเมน สีสด ภาพชัดในห้องทั่วไป☀️", " Google TV ในตัว ดู Netflix, YouTube ได้ทันที ไม่ต้องต่อกล่อง📡"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },

  "12": {
    id: 12, brand: "VIVO", sku: "6932204523716",
    title: "สมาร์ทโฟน vivo Y05 (4+128GB) Summit Platinum", price: 4599,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: ["4+128GB"],
    colors: [{ name: "Summit Platinum" }],
    defaultColor: "Summit Platinum",
    description: "vivo Y05 สมาร์ตโฟนแบตอึด ดีไซน์พรีเมียม ใช้งานได้ยาวนานตลอดวัน ใช้คุ้มทุกเปอร์เซ็นต์ รองรับทุกการใช้งานในชีวิตประจำวัน ไม่ว่าจะทำงาน ดูหนัง ฟังเพลงจับถนัดมือ ให้สัมผัสพรีเมียม พร้อมผ่านการรับรองความทนทานต่อการตกกระแทก ใช้งานได้อย่างมั่นใจในทุกวัน สมารถสั้งซื้อได้แล้ววันนี้ที่ BaNANA",
    specs: ["จอ 6.74 นิ้ว + รีเฟรชเรท 120Hz", "แบตเตอรี่ 6,500 mAh ชาร์จเร็ว 15W", " กล้องหลัก 8MP + กล้องหน้า 5MP"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },

  "13": {
    id: 13, brand: "APPLE", sku: "194253408598",
    title: "Apple iPhone 14 128GB Starlight", price: 17100,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: ["128GB"],
    colors: [{ name: "Starlight" }],
    defaultColor: "Starlight",
    description: "iPhone 14 มาพร้อมระบบกล้องคู่ที่น่าประทับใจที่สุดเท่าที่เคยมีมาบน iPhone ซึ่งถ่ายภาพได้อย่างน่าทึ่งทั้งในที่ที่มีแสงน้อยและแสงจ้า  นอกจากนี้ยังมีการตรวจจับการชนกัน ซึ่งเป็นคุณสมบัติใหม่ด้านความปลอดภัย ที่พร้อมโทรขอความช่วยเหลือเมื่อคุณไม่สามารถ",
    specs: ["จอภาพ Super Retina XDR ขนาด 6.1 นิ้ว", "แ ระบบกล้องสุดล้ำเพื่อภาพถ่ายที่ดียิ่งขึ้นในทุกสภาพแสง", "  ชิป A15 Bionic พร้อม GPU แบบ 5-core เพื่อประสิทธิภาพที่เร็วสุดขั้ว"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },

  "14": {
    id: 14, brand: "VIVO", sku: "6932204509000",
    title: "สมาร์ทโฟน vivo V60 (12+256GB) Mist Gray (5G)", price: 15699,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: ["12+256GB"],
    colors: [{ name: "Mist Gray" }],
    defaultColor: "Mist Gray",
    description: "vivo V60 5G สมาร์ทโฟนเรียบหรู ทุกมุมมองคือความเรียบง่ายที่ลงตัวอย่างแท้จริง ถ่ายภาพพอร์ตเทรตเวทีซูมไกล 10x กันน้ำและป้องกันฝุ่นอย่างดีเยี่ยม การแช่น้ำ และมือที่เปียกหรือมัน ให้คุณใช้งานได้อย่างไร้กังวลในทุกสภาพแวดล้อม พร้อมระบบกันตกขั้นสูง",
    specs: ["หน้าจอ   6.77 นิ้ว", "กล้องหลักคมชัด   50   ล้านพิกเซล", "  แบตเตอรี่ขนาดใหญ่จุใจ   6,500 mAh"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },

  "15": {
    id: 15, brand: "VIVO", sku: "6935117899619",
    title: "สมาร์ทโฟน vivo V60 Lite (8+256GB) Elegant Black (5G)", price: 9999,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: ["8+256GB"],
    colors: [{ name: "Elegant Black" }],
    defaultColor: "Elegant Black",
    description: "vivo V60 Lite 5G ราคาพิเศษที่ BaNANA เท่านั้น สมาร์ทโฟนตัวเครื่องเพรียวบาง มาพร้อมหน้าจอ AMOLED ความสว่าง 1000 นิต   ชิป Dimensity 7360 Turbo รุ่นใหม่ กันน้ำกันฝุ่น IP65 แบตเตอรี่ยาวนานใช้ได้ทั้งวัน เป็นเจ้าของกันได้แล้ววันนี้ปักลงตะกร้าได้เลย",
    specs: ["ขนาดหน้าจอ 6.77 นิ้ว", "กล้องหลัก Sony 50 ล้านพิกเซล", "แบตเตอรี่ 6,500 mAh ชาร์จเร็ว 90W"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },

  "16": {
    id: 1, brand: "VIVO", sku: "6932204512925",
    title: "สมาร์ทโฟน vivo X300 (12+256GB) Phantom Black (5G)", price: 29999,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: ["12+256GB"],
    colors: [{ name: "Phantom Black" }],
    defaultColor: "Phantom Black",
    description: "X300 5G สมาร์ทโฟนจับถนัดมือ หน้าจอเล็กกะทัดรัด พกพาสะดวกแต่ทรงพลังด้วยเลนส์เทเลโฟโต้และชิปคู่สำหรับการถ่ายภาพระดับมืออาชีพ แบตเตอรี่ BlueVolt อึดและชาร์จไว การจัดการพลังงานขั้นสูง ให้แบตเตอรี่อึดขึ้นและน้ำหนักเบา สั่งซื้อเลยที่ BaNANA",
    specs: ["จอ 6.31 นิ้ว", "แบต 6,040 mAh ชาร์จเร็ว 90W", "กล้องหลัง 200MP กลัองหน้า 50MP"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },
  
  "17": {
    id: 1, brand: "VIVO", sku: "6932204513243",
    title: "สมาร์ทโฟน vivo X300 Pro (16+512GB) Dune Brown (5G)", price: 39999,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: ["16+512GB"],
    colors: [{ name: "Dune Brown" }],
    defaultColor: "Dune Brown",
    description: "X300 Pro 5G สมาร์ทโฟนราชาแห่งเลนส์เทเลโฟโต้ในวงการ! มาพร้อมกับชิปคู่สำหรับการถ่ายภาพระดับมืออาชีพ แบตเตอรี่ BlueVol ไม่เพียงแต่มีความจุที่มากขึ้นเท่านั้น แต่ยังใช้เทคโนโลยีซิลิคอนรุ่นที่ 4 และการเพิ่มประสิทธิภาพการใช้พลังงาน น้ำหนักเบาของระบบ สั่งเลยที่ BaNANA",
    specs: ["ขนาดจอ 6.78 นิ้ว", "กล้องเทเลโฟโต้ 200MP กล้องหน้า 50MP", " แบต 6,510 mAh ชาร์จไว 90W ชาร์จไร้สาย 40W"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },

  "18": {
    id: 18, brand: "SAMSUNG", sku: "8806097010821",
    title: "สมาร์ทโฟน Samsung Galaxy S25 Ultra (12+256GB) Titanium Whitesilver (5G)", price: 40900,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: ["12+256GB"],
    colors: [{ name: "Titanium Whitesilver" }],
    defaultColor: "Titanium Whitesilver",
    description: "สั่งซื้อ Galaxy S25 Ultra พร้อมส่วนลดราคาพิเศษได้ที่ BaNANA มาพร้อมปากกา S Pen ที่เป็นมากกว่าปากกา เปรียบเสมือนผู้ช่วยส่วนตัว ใช้สั่งถ่ายรูป เปลี่ยนสไลด์ แปลภาษา แต่งรูป เล่นเกม พร้อมด้วยกล้องคุณภาพสูง ถ่ายภาพสวย คมชัด เก็บครบทุกรายละเอียด",
    specs: ["ขนาดหน้าจอ 6.9 นิ้ว", "แบตเตอรี่ 5,000 mAh ชาร์จเร็ว 45W", "กล้องหลัก 200MP กล้องหน้า 12MP"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },

  "19": {
    id: 19, brand: "FENDER", sku: "8885021970158",
    title: "ลำโพงบลูทูธ FenderELIE 12 White", price: 17900,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: [],
    colors: [{ name: "White" }],
    defaultColor: "White",
    description: "ลำโพงบลูทูธดีไซน์พรีเมียมสไตล์แอมป์กีตาร์จาก Fender ให้พลังเสียงคมชัด เบสแน่น ฟังสนุกทุกแนวดนตรี เชื่อมต่อ Bluetooth ได้รวดเร็ว ใช้งานง่าย เหมาะทั้งตั้งโต๊ะทำงาน คาเฟ่ หรือพกไปปาร์ตี้ เติมบรรยากาศดนตรีระดับตำนานในทุกช่วงเวลาของคุณ ซื้อสินค้าแล้วได้ที่ BaNANA",
    specs: ["ชาร์จเร็วทันใจ", "มาตรฐานกันน้ำกันฝุ่นระดับ IP54", "รองรับระบบเสียงสเตอริโอ / เชื่อมต่อหลายตัว"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },

  "20": {
    id: 20, brand: "SAMSUNG", sku: "8806097875130",
    title: "แท็บเล็ต Samsung Galaxy Tab A11+ 5G (6+128GB) Gray", price: 8990,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: ["6+128GB"],
    colors: [{ name: "Gray" }],
    defaultColor: "Gray",
    description: "Galaxy Tab A11+ 5G แท็บเล็ตจอใหญ่ขนาด 11 นิ้ว 90Hz เพลิดเพลินกับภาพที่คมชัดลื่นไหล  มาพร้อมกับลำโพง Quad Speakers ดื่มด่ำกับเสียงคุณภาพเสียงรอบทิศทาง แบตเตอรี่ 7,040 mAh ใช้ได้ยาวนานและรองรับการชาร์จไฟ 25W ใช้งานเป็นไปอย่างราบรื่น ไม่มีสะดุด   ซื้อสินค้าได้ที่ BaNANA ส่งเร็วทันใจ",
    specs: ["หน้าจอ 11 นิ้ว", "ชิป MT8775(MTK)", "แบตเตอรี่จุใจ 7,040 mAh"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },

  "21": {
    id: 21, brand: "MSI", sku: "4711377337236",
    title: "จอมอนิเตอร์ MSI MAG 272PF X24 Gaming Monitor (Rapid IPS 240Hz)", price: 4690,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: [],
    colors: [{ name: "Black" }],
    defaultColor: "Black",
    description: "จอมอนิเตอร์ MSI MAG 272PF X24 มาพร้อมแผงหน้าจอความละเอียด Full HD มีอัตรารีเฟรชเรทที่สูง และเวลาตอบสนองที่รวดเร็ว 0.5ms จอภาพรองรับ HDR ช่วยเพิ่มรายละเอียดที่คมชัดยิ่งขึ้นด้วยการปรับคอนทราสต์และเงา ออกแบบมาสำหรับเกม FPS แนวแข่งขัน เกม RPG/MMORPG มุมมองบุคคลที่หนึ่ง และเกมจำลองการบิน/แข่งรถ สั่งซื้อได้ที่ BaNANA",
    specs: ["หน้าจอ IPS 27 นิ้ว", "ความละเอียด 1920 x 1080", " รีเฟรชเรทสูงสุด 240 Hz"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },

  "22": {
    id: 22, brand: "XIAOMI", sku: "6932554481636",
    title: "สมาร์ทโฟน Xiaomi Redmi Note 15 Pro+ (12+512GB) Mocha Brown (5G)", price: 13990,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: ["12+512GB"],
    colors: [{ name: "Mocha Brown" }],
    defaultColor: "Mocha Brown",
    description: "Redmi Note 15 Pro+   สมาร์ทโฟนป้องกันการตกกระแทก 2.5 เมตรตามมาตรฐาน SGS มาตรฐาน IP69K ทนทานต่อแรงดันน้ำ 176°F ที่แรงดัน 1,450 psi  แช่น้ำลึกได้ 2 เมตร นานถึง 24 ชั่วโมง กล้องรุ่นใหม่ ถ่ายชัดทุกมุมมอง จับคู่กับเลนส์ Ultra-wide คมชัดทุกรายละเอียด สั่งเลยที่ BaNANA",
    specs: ["ขนาดจอ 6.83 นิ้ว", "กล้องหลัก 200MP กล้องหน้า 32MP", "แบต 6,500 mAh ชาร์จเร็ว 100W"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },


  "23": {
    id: 23, brand: "JOYROOM", sku: "6956116770143",
    title: "หูฟัง JOYROOM TYPE-C Series JR-EC06 Silver", price: 249,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: [],
    colors: [{ name: "Silver" }],
    defaultColor: "Silver",
    description: "ฟังเพลงสนุกด้วยเสียงที่ชัดเจนด้วย หูฟัง JOYROOM JR-EC06  หูฟังแบบจุกซิลิโคนที่เป็นมิตรต่อผิวหนัง การออกแบบเอียง 45° กระชับพอดีสวมใส่สบายยาวนาน วัสดุสายเป็น TPE นุ่ม ยืดหยุ่นและทนทาน จัดเก็บง่าย ขั้วต่อดิจิทัล Type-C ที่รองรับหลากหลายส่งสัญญาณได้เสถียร",
    specs: ["ขั้วต่อ Type-C", "ไมโครโฟนคุณภาพสูง", "วัสดุสาย TPE ยืดหยุ่นทนทาน"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },


  "24": {
    id: 24, brand: "AMAZFIT", sku: "6970100377866",
    title: "สมาร์ทวอทช์ Amazfit Bip 6 Black", price: 2690,
    warranty: "รับประกัน 1 ปี", isNew: true, isPreOrder: false,
    images: ["/img/sony.jpg", "/img/sony.jpg", "/img/sony.jpg"],
    capacities: [],
    colors: [{ name: "Black" }],
    defaultColor: "Black",
    description: "สมาร์ทวอทช์ Amazfit Bip 6  ⌚ หน้าจอสวยงามและคมชัด AMOLED ขนาดใหญ่ 1.97 นิ้ว มีความสว่างสูงถึง 2,000 นิต ทำให้มองเห็นชัดเจนในทุกสภาพแสง   🌟 พร้อม GPS ที่สามารถจับสัญญาณได้รวดเร็ว และติดตามเส้นทางได้อย่างแม่นยำ แม้ในพื้นที่ที่มีสิ่งกีดขวาง   เป็นเจ้าของได้แล้ววันนี้ที่ BaNANA",
    specs: ["รับสาย - โทรออก ผ่าน Bluetooth", "ควบคุมเสียงผ่าน Zepp Flow ได้", "มีเซ็นเซอร์ BioTracker 6.0 สำหรับวัดค่าสุขภาพต่าง ๆ"],
    shippingNote: "จัดส่งภายใน 1–3 วันทำการ",
  },

};





export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();

  const product = mockProducts[id as string];
  const [activeImg, setActiveImg] = useState(0);
  const [selectedCap, setSelectedCap] = useState(product?.capacities?.[0] ?? "");
  const [selectedColor, setSelectedColor] = useState(product?.defaultColor ?? "");
  const [withAddon, setWithAddon] = useState(false);
  const [qty, setQty] = useState(1);
  const [couponSaved, setCouponSaved] = useState(false);

  if (!product) {
    return (
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-grow flex items-center justify-center">
          <p className="text-gray-500 text-lg">ไม่พบสินค้า</p>
        </main>
        <Footer />
      </div>
    );
  }

  const totalPrice = product.price + (withAddon ? product.addon.price : 0);

  const handleAddToCart = () => {
    addToCart({
      id: product.id,
      name: `${product.title}${selectedCap ? " " + selectedCap : ""} ${selectedColor}`.trim(),
      brand: product.brand,
      price: totalPrice,
      image: product.images[0],
      color: [selectedCap, selectedColor].filter(Boolean).join(" | "),
    });
  };

  const handleBuyNow = () => { handleAddToCart(); navigate("/cart"); };
  const prevImg = () => setActiveImg((p) => (p - 1 + product.images.length) % product.images.length);
  const nextImg = () => setActiveImg((p) => (p + 1) % product.images.length);

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Navbar />
      <main className="flex-grow">
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-start">

            {/* ===== LEFT: GALLERY ===== */}
            <div className="md:sticky md:top-24">
              <div className="relative rounded-2xl overflow-hidden border-2 border-yellow-400 bg-white">
                <button onClick={prevImg} className="absolute left-3 top-1/3 -translate-y-1/2 z-10 bg-white/80 hover:bg-yellow-400 border border-gray-200 rounded-full w-9 h-9 flex items-center justify-center shadow transition">
                  <ChevronLeft size={20} />
                </button>
                <img src={product.images[activeImg]} alt={product.title} className="w-full h-96 object-contain p-6"
                  onError={(e) => ((e.target as HTMLImageElement).src = "https://placehold.co/400x400?text=No+Image")} />
                <div className="bg-yellow-400 px-6 py-3 flex items-center gap-3">
                  <span className="bg-red-600 text-white text-xs font-black px-2 py-1 rounded -skew-x-3">NEW</span>
                  <span className="font-black text-lg">🕊️ ของใหม่เข้าแล้ว 🕊️</span>
                </div>
                <button onClick={nextImg} className="absolute right-3 top-1/3 -translate-y-1/2 z-10 bg-white/80 hover:bg-yellow-400 border border-gray-200 rounded-full w-9 h-9 flex items-center justify-center shadow transition">
                  <ChevronRight size={20} />
                </button>
              </div>
              <div className="flex gap-3 mt-4 flex-wrap">
                {product.images.map((img: string, i: number) => (
                  <button key={i} onClick={() => setActiveImg(i)}
                    className={`w-20 h-20 rounded-xl border-2 p-1.5 bg-white transition ${activeImg === i ? "border-yellow-400" : "border-gray-200 hover:border-gray-400"}`}>
                    <img src={img} alt={`thumb-${i}`} className="w-full h-full object-contain"
                      onError={(e) => ((e.target as HTMLImageElement).src = "https://placehold.co/80x80?text=img")} />
                  </button>
                ))}
              </div>
            </div>

            {/* ===== RIGHT: INFO ===== */}
            <div className="space-y-5">
              <div>
                <h1 className="text-2xl font-bold text-gray-900 leading-snug">{product.title}</h1>
                <p className="text-sm text-gray-400 mt-1">
                  แบรนด์: <span className="font-semibold text-gray-600">{product.brand}</span>
                  <span className="mx-2 text-gray-300">|</span> SKU: {product.sku}
                </p>
              </div>

              <p className="text-4xl font-extrabold text-red-500">฿{product.price.toLocaleString()}</p>

              <div className="flex items-center gap-2 text-sm text-gray-400">
                <Shield size={13} /> {product.warranty}
              </div>

              <div className="flex gap-2 flex-wrap items-center">
                {product.isNew && <span className="bg-red-600 text-white text-xs font-black px-3 py-1.5 rounded -skew-x-3">NEW!</span>}
                {product.isPreOrder && <span className="bg-blue-700 text-white text-xs font-bold px-2.5 py-1 rounded text-center leading-tight">PRE<br />ORDER</span>}
                <button className="bg-yellow-400 text-black text-xs font-bold px-3 py-1.5 rounded flex items-center gap-1 hover:bg-yellow-300 transition">
                  ฿<sub className="text-[10px]">0%</sub> ดูเพิ่มเติม
                </button>
              </div>

              {/* Capacity */}
              {product.capacities.length > 0 && (
                <div>
                  <p className="text-sm text-gray-500 font-medium mb-2">Capacity</p>
                  <div className="flex gap-2 flex-wrap">
                    {product.capacities.map((cap: string) => (
                      <button key={cap} onClick={() => setSelectedCap(cap)}
                        className={`px-5 py-2 rounded-lg border-2 text-sm font-semibold transition ${selectedCap === cap ? "border-gray-900 bg-gray-900 text-white" : "border-gray-200 hover:border-gray-400 text-gray-700"}`}>
                        {cap}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Color */}
              {product.colors && product.colors.length > 0 && (
                <div>
                  <p className="text-sm text-gray-500 font-medium mb-2">
                    Color <span className="font-bold text-gray-900">{selectedColor}</span>
                  </p>

                  <div className="flex gap-3">
                    {product.colors.map((c: { name: string; hex: string }) => (
                      <button
                        key={c.name}
                        onClick={() => setSelectedColor(c.name)}
                        title={c.name}
                        style={{ backgroundColor: c.hex }}
                        className={`w-9 h-9 rounded-full border-4 transition ${selectedColor === c.name
                            ? "border-gray-900 scale-110"
                            : "border-gray-200 hover:border-gray-400"
                          }`}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Description */}
              <div className="border-t pt-4 space-y-3">
                <p className="text-sm text-gray-600 leading-relaxed">{product.description}</p>
                <ul className="space-y-1">
                  {product.specs.map((s: string, i: number) => (
                    <li key={i} className="text-sm text-gray-600 flex items-start gap-2">
                      <span className="text-yellow-500 mt-0.5 flex-shrink-0">•</span>{s}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Quantity */}
              <div className="flex items-center gap-4">
                <span className="text-sm text-gray-500 font-medium">จำนวน</span>
                <div className="flex items-center border border-gray-200 rounded-lg overflow-hidden">
                  <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-lg font-medium transition">−</button>
                  <span className="px-6 py-2 font-semibold text-sm min-w-[3rem] text-center">{qty}</span>
                  <button onClick={() => setQty((q) => q + 1)} className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-lg font-medium transition">+</button>
                </div>
              </div>

              <p className="text-xs text-gray-400 bg-gray-100 rounded-lg px-3 py-2">📦 {product.shippingNote}</p>

              {/* CTA */}
              <div className="space-y-3 pt-1">
                <button onClick={handleBuyNow} className="w-full bg-yellow-400 hover:bg-yellow-300 active:scale-95 text-black font-black py-4 rounded-xl text-base transition">
                  สั่งซื้อ/จองส่วนหน้าเต็มจำนวน ฿{totalPrice.toLocaleString()}
                </button>
                <button onClick={handleAddToCart} className="w-full bg-white hover:bg-black hover:text-white active:scale-95 text-black border-2 border-black font-bold py-3.5 rounded-xl text-base transition">
                  🛒 เพิ่มลงตะกร้า
                </button>
              </div>

              <div className="flex justify-center gap-6 pb-4">
                {[{ icon: <BarChart2 size={14} />, label: "เปรียบเทียบสินค้า" }, { icon: <Heart size={14} />, label: "เพิ่มเป็นรายการโปรด" }, { icon: <Share2 size={14} />, label: "แชร์" }]
                  .map(({ icon, label }) => (
                    <button key={label} className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-yellow-500 transition">
                      {icon} {label}
                    </button>
                  ))}
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}